import sys
import json
import importlib
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout
from PySide6.QtCore import QThreadPool
from widgets.base_widget import create_widget
from actions import Actions


class CustomWidgetApp(QWidget):
    """
    Main application class for dynamically loading and displaying widgets.
    """

    DEFAULT_CONTAINER_STYLE = {
        "background-color": "rgba(0, 0, 0, 0.7)",
        "border": "2px solid gray",
        "border-radius": "10px"
    }

    def __init__(self, config_file):
        super().__init__()
        self.setWindowTitle("Custom Widgets App")
        self.setGeometry(100, 100, 800, 600)

        self.threadpool = QThreadPool()

        with open(config_file, 'r') as file:
            config = json.load(file)

        user_config = config.pop("user_config", {})
        self.function_map = self.load_actions(user_config)

        self.main_layout = QVBoxLayout(self)
        self.widgets = {}
        self.load_widgets(config)

    def load_actions(self, user_config):
        """
        Load actions dynamically with user configuration.
        """
        base_actions = Actions(user_config)
        function_map = {
            attr: getattr(base_actions, attr)
            for attr in dir(base_actions)
            if callable(getattr(base_actions, attr)) and not attr.startswith("__")
        }
        return function_map

    def load_widgets(self, config):
        """
        Load and process widgets from a JSON configuration file.
        """
        for container_name, container_config in config.items():
            try:
                self.process_container(container_name, container_config)
            except Exception as e:
                print(f"Error processing container '{container_name}': {e}")

    def process_container(self, name, config):
        """
        Process and create a container with its widgets.
        """
        required_keys = ["type", "position", "size", "widgets"]
        for key in required_keys:
            if key not in config:
                raise ValueError(f"Missing required key '{key}' in container '{name}'.")

        container = QWidget(self)
        container.setGeometry(
            config["position"][0], config["position"][1],
            config["size"][0], config["size"][1]
        )

        container_style = config.get("style", {})
        stylesheet = self.format_styles(container_style, self.DEFAULT_CONTAINER_STYLE)
        container.setStyleSheet(stylesheet)

        container_layout = QVBoxLayout(container)

        for widget_conf in config["widgets"]:
            widget_id = widget_conf.get("id")
            widget = create_widget(container, container_layout, widget_conf, self.threadpool, self.function_map)
            if widget_id:
                self.widgets[widget_id] = widget

        self.main_layout.addWidget(container)

    @staticmethod
    def format_styles(style, defaults=None):
        """
        Merge provided styles with default styles and convert to CSS string.
        """
        if defaults is None:
            defaults = {}
        merged_style = defaults.copy()
        merged_style.update(style)
        return "; ".join(f"{key}: {value}" for key, value in merged_style.items())



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CustomWidgetApp("widgets_config.json")
    window.show()
    sys.exit(app.exec())
