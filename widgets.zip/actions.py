import os
import psutil


class Actions:
    """
    Core actions available to widgets.
    """

    def __init__(self, user_config: dict):
        self.user_config = user_config
        self.default_host = user_config.get("default_host", "google.com")

    def ping_device(self, host=None):
        target_host = host or self.default_host
        command = f"ping -c 1 {target_host}" if os.name != "nt" else f"ping -n 1 {target_host}"
        response = os.system(command)
        return f"Ping to {target_host} successful." if response == 0 else f"Ping to {target_host} failed."

    def get_cpu_usage(self):
        return f"CPU Usage: {psutil.cpu_percent()}%"

    def get_memory_usage(self):
        memory = psutil.virtual_memory()
        return f"Memory Usage: {memory.used / 1024 ** 2:.2f} MB / {memory.total / 1024 ** 2:.2f} MB"

    def get_disk_usage(self):
        disk = psutil.disk_usage('/')
        return f"Disk Usage: {disk.used / 1024 ** 3:.2f} GB / {disk.total / 1024 ** 3:.2f} GB ({disk.percent}%)"
