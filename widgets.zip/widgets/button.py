from PySide6.QtWidgets import QPushButton
from tasks import TaskRunner


def create_button(parent, layout, config, threadpool, function_map):
    """
    Create a button widget.
    """
    button = QPushButton(config.get("text", ""), parent)
    button.setStyleSheet(config["style"])

    def on_button_click():
        for action in config.get("action", []):
            task = TaskRunner(action, function_map)
            task.signals.result.connect(lambda result: print(f"Task result: {result}"))
            threadpool.start(task)

    button.clicked.connect(on_button_click)
    layout.addWidget(button)
    return button
