from PySide6.QtWidgets import QComboBox, QLabel
from tasks import TaskRunner


def create_dropdown(parent, layout, config, threadpool, function_map):
    """
    Create a dropdown widget.
    """
    dropdown = QComboBox(parent)
    label_text = config.get("label", "Select an option:")
    dropdown_label = QLabel(label_text, parent)

    dropdown.setStyleSheet(config["style"])

    for item in config.get("items", []):
        dropdown.addItem(item["text"])

    def on_item_selected(index):
        action = config["items"][index].get("action")
        if action in function_map:
            task = TaskRunner({"type": "python", "function": action}, function_map)
            task.signals.result.connect(lambda result: print(f"Dropdown action result: {result}"))
            threadpool.start(task)

    dropdown.currentIndexChanged.connect(on_item_selected)
    layout.addWidget(dropdown_label)
    layout.addWidget(dropdown)
    return dropdown
