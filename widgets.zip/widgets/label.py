from PySide6.QtWidgets import QLabel


def create_label(parent, layout, config):
    """
    Create a label widget.
    """
    label = QLabel(config.get("text", ""), parent)
    label.setStyleSheet(config["style"])  # Apply styles
    layout.addWidget(label)
    return label
