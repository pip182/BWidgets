from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPainter
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QLabel, QWidget
from PySide6.QtCharts import QChart, QChartView, QLineSeries, QValueAxis
from ping3 import ping
from collections import deque


class LatencyChart(QWidget):
    """
    A latency monitor widget with a line chart and latency statistics.
    """

    def __init__(self, parent=None, config=None):
        super().__init__(parent)

        self.target_host = config.get("target_host", "google.com")
        self.interval = config.get("interval", 1000)
        self.max_points = config.get("max_points", 180)

        self.latency_data = deque([0] * self.max_points, maxlen=self.max_points)
        self.lost_packets = 0
        self.total_packets = 0
        self.irregular_latency_count = 0

        self.main_layout = QVBoxLayout(self)
        self.init_chart()
        self.init_labels()

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_plot)
        self.timer.start(self.interval)

    def init_chart(self):
        self.series = QLineSeries()
        self.chart = QChart()
        self.chart.addSeries(self.series)
        self.chart.setTitle(f"Latency Monitoring to {self.target_host}")

        self.axisX = QValueAxis()
        self.axisX.setTitleText("Time")
        self.axisX.setRange(0, self.max_points)
        self.chart.addAxis(self.axisX, Qt.AlignBottom)
        self.series.attachAxis(self.axisX)

        self.axisY = QValueAxis()
        self.axisY.setTitleText("Latency (ms)")
        self.axisY.setRange(0, 200)
        self.chart.addAxis(self.axisY, Qt.AlignLeft)
        self.series.attachAxis(self.axisY)

        self.chart_view = QChartView(self.chart)
        self.chart_view.setRenderHint(QPainter.Antialiasing)
        self.main_layout.addWidget(self.chart_view)

    def init_labels(self):
        self.label_layout = QHBoxLayout()
        self.sent_label = QLabel("Packets Sent: 0")
        self.lost_label = QLabel("Packets Lost: 0")
        self.avg_latency_label = QLabel("Average Latency: 0 ms")
        self.irregular_label = QLabel("Irregular Latencies: 0")
        self.label_layout.addWidget(self.sent_label)
        self.label_layout.addWidget(self.lost_label)
        self.label_layout.addWidget(self.avg_latency_label)
        self.label_layout.addWidget(self.irregular_label)

        self.main_layout.addLayout(self.label_layout)

    def update_plot(self):
        latency = ping(self.target_host, timeout=1)
        self.total_packets += 1

        if latency is None:
            self.lost_packets += 1
            self.latency_data.append(0)
        else:
            latency_ms = latency * 1000
            self.latency_data.append(latency_ms)
            avg_latency = (
                sum([x for x in self.latency_data if x > 0])
                / len([x for x in self.latency_data if x > 0])
                if self.latency_data
                else 0
            )
            if latency_ms > 3 * avg_latency:
                self.irregular_latency_count += 1

        self.series.clear()
        for i, latency in enumerate(self.latency_data):
            self.series.append(i, latency)

        max_latency = max(self.latency_data)
        self.axisY.setRange(0, max_latency * 1.2 if max_latency > 0 else 200)

        self.sent_label.setText(f"Packets Sent: {self.total_packets}")
        self.lost_label.setText(f"Packets Lost: {self.lost_packets}")
        self.avg_latency_label.setText(f"Average Latency: {avg_latency:.2f} ms")
        self.irregular_label.setText(f"Irregular Latencies: {self.irregular_latency_count}")
