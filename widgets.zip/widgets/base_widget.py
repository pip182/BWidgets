from widgets.button import create_button
from widgets.dropdown import create_dropdown
from widgets.label import create_label
from widgets.table import create_table
from widgets.latency_chart import LatencyChart


def create_widget(parent, layout, config, threadpool, function_map):
    """
    Create a widget based on its type.
    """
    widget_type = config.get("type")
    if widget_type == "label":
        return create_label(parent, layout, config)
    elif widget_type == "button":
        return create_button(parent, layout, config, threadpool, function_map)
    elif widget_type == "dropdown":
        return create_dropdown(parent, layout, config, threadpool, function_map)
    elif widget_type == "table":
        return create_table(parent, layout, config)
    elif widget_type == "latency_chart":
        chart = LatencyChart(parent, config)
        layout.addWidget(chart)
        return chart
    else:
        raise ValueError(f"Unknown widget type: {widget_type}")
