from PySide6.QtWidgets import QTableWidget, QTableWidgetItem


def create_table(parent, layout, config):
    """
    Create a table widget.
    """
    table = QTableWidget(parent)
    table.setColumnCount(len(config.get("columns", [])))
    table.setHorizontalHeaderLabels(config.get("columns", []))
    table.setStyleSheet(config["style"])

    example_data = [["Alice", 30], ["Bob", 25]]
    table.setRowCount(len(example_data))
    for row_idx, row_data in enumerate(example_data):
        for col_idx, cell_data in enumerate(row_data):
            table.setItem(row_idx, col_idx, QTableWidgetItem(str(cell_data)))

    layout.addWidget(table)
    return table
