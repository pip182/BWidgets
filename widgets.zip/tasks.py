from PySide6.QtCore import QRunnable, QObject, Signal
import subprocess


class TaskSignals(QObject):
    result = Signal(str)


class TaskRunner(QRunnable):
    """
    Executes actions in a separate thread.
    """

    def __init__(self, action, function_map):
        super().__init__()
        self.action = action
        self.function_map = function_map
        self.signals = TaskSignals()

    def run(self):
        action_type = self.action.get("type")
        result = ""

        try:
            if action_type == "shell":
                result = self.run_shell_command(self.action.get("command"))
            elif action_type == "python":
                result = self.run_python_function(self.action.get("function"))
            else:
                result = f"Unknown action type: {action_type}"
        except Exception as e:
            result = f"Task execution error: {e}"

        self.signals.result.emit(result)

    def run_shell_command(self, command):
        if not command:
            return "No command specified."
        try:
            process = subprocess.run(command, shell=True, capture_output=True, text=True)
            return process.stdout.strip() if process.returncode == 0 else process.stderr.strip()
        except Exception as e:
            return f"Shell command error: {e}"

    def run_python_function(self, function_name):
        if function_name not in self.function_map:
            return f"Function '{function_name}' not found."
        try:
            return self.function_map[function_name]()
        except Exception as e:
            return f"Python function error: {e}"
